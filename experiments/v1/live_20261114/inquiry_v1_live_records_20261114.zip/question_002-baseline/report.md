# Controlled inquiry

Not established: The supplied evidence supports that some street flooding occurred in North Wharf block on the morning of 4 April 2026.

Scope: {"location_id": "area_001", "location_name": "North Wharf block", "outcome": "street flooding", "period": "2026-04-04T06:00/2026-04-04T12:00", "quantifier": "some street flooding within the named block"}

Proposed next step: Supported scoped event finding is established on the revised graph; no further investigation needed.

Basis: doc_002 v1.0 [paragraph_1]

## Run

- Status: complete
- Stop: settled_for_purpose
- Arm: harness
- Evidence mode: documents
- Task completed: True

- Support is limited to some street flooding within North Wharf block during 06:00-12:00 on 4 April 2026.
- The bulletin does not support broader claims about every address, worker, household, or related losses.
- Standing is relative to the recorded arguments, source interpretations and stated profile; it is not a guarantee of truth.
- This result supplies analysis and a proposed response, not permission to execute an action.
