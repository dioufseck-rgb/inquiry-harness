"""Resume only unsaved cases after an external process interruption.
All input is the repository's explicitly synthetic public development packet.
No real application data or private user documents are read.
"""
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
import getpass
import json
import os
import subprocess
from inquiry.v1.experiments import summarize_runs
from inquiry.v1.packets import load_packet
from inquiry.v1.persistence import save_run
from inquiry.v1.runtime import Budget, IMPLEMENTATION_HASHES, replay_run, run_inquiry
from inquiry.v1.scoring import hardship_smoke_expectation, score_run
from inquiry.v1.workers import LLMWorker
ROOT=Path("runs/v1/requested-20261114")
protocol=json.loads((ROOT/"protocol.json").read_text())
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==protocol["commit"]
assert IMPLEMENTATION_HASHES==protocol["implementation_hashes"]
packet=load_packet()
assert packet.packet_hash==protocol["packet_hash"]
records=[json.loads(line) for line in (ROOT/"runs.jsonl").read_text().splitlines() if line.strip()]
done={r["case_id"] for r in records}
remaining=[(j["question"],j["mutation"]) for j in protocol["order"] if j["question"]+"-"+(j["mutation"] or "baseline") not in done]
assert remaining==[("question_003","mutation_003"),("question_005",None),("question_006",None)]
notice=packet.public("question_003","mutation_003")["shared_context"]["fiction_notice"]
assert "Every programme, person, entity, place, date, amount, and record in this exercise is synthetic" in notice
interruption={"recorded_at":datetime.now(timezone.utc).isoformat(),"reason":"Automatic approval review rejected a read-only status poll on the mistaken premise that the wholly synthetic packet was private applicant data; the process was then unavailable.","verified_fiction_notice":notice,"saved_completed_cases":sorted(done),"interrupted_case":"question_003-mutation_003","interrupted_attempt_usage":"unknown: no final result or worker ledger persisted for this attempt","resume_cases":remaining,"settings":"unchanged from protocol.json","completed_cases_will_not_be_repeated":True}
with (ROOT/"interruption.json").open("x") as f: json.dump(interruption,f,indent=2); f.write("\n")
print("Verified wholly synthetic input; resuming three unsaved cases, with completed results preserved.",flush=True)
os.environ["OPENAI_API_KEY"]=getpass.getpass("Temporary API credential (hidden): ")
try:
    for question,mutation in remaining:
        case_id=question+"-"+(mutation or "baseline")
        assert not (ROOT/case_id).exists()
        print(json.dumps({"starting_resumed_case":case_id}),flush=True)
        public=packet.public(question,mutation)
        worker=LLMWorker.from_spec(protocol["proposer"],effort=protocol["effort"])
        critic=LLMWorker.from_spec(protocol["critic"],effort=protocol["effort"])
        result=run_inquiry(public,worker,arm=protocol["arm"],mode=protocol["mode"],budget=Budget(**protocol["budget"]),critic=critic)
        directory=save_run(result,ROOT/case_id)
        assessment=score_run(result,public,answer_spec=packet.oracle(question,mutation),smoke_expectation=hardship_smoke_expectation(question,mutation))
        (directory/"assessment.json").write_text(json.dumps(assessment,indent=2)+"\n")
        replay={k:v for k,v in replay_run(result).items() if k!="evaluation"}
        record={"case_id":case_id,"question_id":question,"mutation_id":mutation,"result":result,"score":assessment,"replay":replay,"attempt_elapsed_seconds":result["usage"]["elapsed_seconds"],"resumed_after_external_interruption":True}
        records.append(record)
        with (ROOT/"runs.jsonl").open("a") as f: f.write(json.dumps(record)+"\n")
        target=next((x for x in result["response"]["findings"] if x["claim_id"]==result["response"]["target_claim_id"]),{})
        print(json.dumps({"finished_total":len(records),"case":case_id,"status":result["status"],"standing":target.get("status"),"next_action":result["response"]["next_action"],"structural":assessment["structural"]["status"],"smoke":assessment["smoke"]["status"],"calls":result["usage"]["model_calls"],"seconds":result["usage"]["elapsed_seconds"],"errors":result["errors"],"replay":replay}),flush=True)
        if any("AuthenticationError" in e or "insufficient_quota" in e for e in result["errors"]): break
finally:
    os.environ.pop("OPENAI_API_KEY",None)
    output={"protocol":protocol,"summary":summarize_runs(records),"completed_records":len(records),"external_interruption":interruption}
    (ROOT/"summary.json").write_text(json.dumps(output,indent=2)+"\n")
    print(json.dumps(output["summary"],indent=2),flush=True)
