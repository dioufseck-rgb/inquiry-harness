"""Run the frozen v1 harness on the requested controlled development set."""
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
import getpass
import json
import os
import subprocess

from inquiry.v1.experiments import ExperimentCase, summarize_runs
from inquiry.v1.packets import load_packet
from inquiry.v1.persistence import digest, save_run
from inquiry.v1.runtime import Budget, IMPLEMENTATION_HASHES, build_prompt, replay_run, run_inquiry
from inquiry.v1.scoring import hardship_smoke_expectation, score_run
from inquiry.v1.workers import LLMWorker

ROOT = Path("runs/v1/requested-20261114")
ROOT.mkdir(parents=True, exist_ok=False)
packet = load_packet()
jobs = [("question_004", None), ("question_004", "mutation_002"),
        ("question_001", None), ("question_002", None), ("question_003", None),
        ("question_003", "mutation_003"), ("question_005", None), ("question_006", None)]
budget = Budget(max_model_calls=10, max_tool_calls=8, max_total_tokens=160000,
                max_output_tokens=8192, timeout_seconds=180, max_critique_calls=1)
proposer = "openai:gpt-5.4-mini-2026-03-17"
critic = "openai:gpt-5.4-2026-03-05"
protocol = {"kind": "prespecified_live_development_run", "created_at": datetime.now(timezone.utc).isoformat(),
            "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "working_tree_clean": not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip(),
            "proposer": proposer, "critic": critic, "effort": "low", "mode": "documents", "arm": "harness",
            "budget": asdict(budget), "implementation_hashes": IMPLEMENTATION_HASHES,
            "prompt_hash": digest(build_prompt("harness")), "packet_hash": packet.packet_hash,
            "repetitions": 1, "order": [{"question": q, "mutation": m} for q, m in jobs],
            "expectations": [{"question": q, "mutation": m, "smoke": hardship_smoke_expectation(q, m)} for q, m in jobs],
            "interpretation": "One synthetic development family; no human gold or architectural comparison. No code changes or post-result reruns during this batch."}
(ROOT / "protocol.json").write_text(json.dumps(protocol, indent=2)+"\n")
os.environ["OPENAI_API_KEY"] = getpass.getpass("Temporary API credential (hidden): ")
records = []
try:
    for number, (question, mutation) in enumerate(jobs, 1):
        case_id = question + "-" + (mutation or "baseline")
        public = packet.public(question, mutation)
        print(json.dumps({"starting": number, "total": len(jobs), "case": case_id}), flush=True)
        worker = LLMWorker.from_spec(proposer, effort="low")
        challenger = LLMWorker.from_spec(critic, effort="low")
        result = run_inquiry(public, worker, arm="harness", mode="documents", budget=budget, critic=challenger)
        directory = save_run(result, ROOT / case_id)
        assessment = score_run(result, public, answer_spec=packet.oracle(question, mutation),
                               smoke_expectation=hardship_smoke_expectation(question, mutation))
        (directory / "assessment.json").write_text(json.dumps(assessment, indent=2)+"\n")
        replay = {k: v for k, v in replay_run(result).items() if k != "evaluation"}
        record = {"case_id": case_id, "question_id": question, "mutation_id": mutation,
                  "result": result, "score": assessment, "replay": replay,
                  "attempt_elapsed_seconds": result["usage"]["elapsed_seconds"]}
        records.append(record)
        with (ROOT / "runs.jsonl").open("a") as stream:
            stream.write(json.dumps(record)+"\n")
        target = next((f for f in result["response"]["findings"] if f["claim_id"] == result["response"]["target_claim_id"]), {})
        print(json.dumps({"finished": number, "case": case_id, "status": result["status"],
                          "standing": target.get("status"), "next_action": result["response"]["next_action"],
                          "structural": assessment["structural"]["status"], "smoke": assessment["smoke"]["status"],
                          "calls": result["usage"]["model_calls"], "seconds": result["usage"]["elapsed_seconds"],
                          "errors": result["errors"], "replay": replay}), flush=True)
        if any("AuthenticationError" in e or "insufficient_quota" in e for e in result["errors"]):
            print("Stopping on provider authentication or quota failure.", flush=True)
            break
finally:
    os.environ.pop("OPENAI_API_KEY", None)
    output = {"protocol": protocol, "summary": summarize_runs(records), "completed_records": len(records)}
    (ROOT / "summary.json").write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps(output["summary"], indent=2), flush=True)
