"""Read-only audit of saved calls; never constructs a worker or calls a provider.

Run from the repository root with PYTHONDONTWRITEBYTECODE=1 python
runs/v1/requested-20261114/audit/protocol_audit.py. Only this audit directory
receives output. The review covers transport/record mechanics, not truth.
"""
from __future__ import annotations

import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[4]))

from pydantic import BaseModel, ConfigDict, ValidationError
from inquiry.llm import extract_json
from inquiry.v1.models import Attack
from inquiry.v1.persistence import load_run
from inquiry.v1.runtime import Operation, replay_run


class PromptedCritique(BaseModel):
    """Audit-only interpretation of the prompt; runtime has no such validator."""
    model_config = ConfigDict(extra="forbid")
    observations: list[str]
    attacks: dict[str, Attack]


def validation(schema, value):
    try:
        schema.model_validate(value)
        return {"valid": True}
    except ValidationError as exc:
        return {"valid": False, "errors": [
            {"location": list(e["loc"]), "type": e["type"], "message": e["msg"]}
            for e in exc.errors(include_input=False)
        ]}


def split_reply(reply):
    # Mirror extract_json's preprocessing, then retain every adjacent object.
    text = reply.strip()
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    if fence:
        text = fence.group(1)
    pos = text.find("{")
    objects = []
    while 0 <= pos < len(text) and text[pos] == "{":
        try:
            obj, end = json.JSONDecoder().raw_decode(text, pos)
        except json.JSONDecodeError:
            break
        objects.append({"object": obj, "start": pos, "end": end})
        pos = end
        while pos < len(text) and text[pos].isspace():
            pos += 1
    return objects, text[pos:] if pos >= 0 else text


def summary(obj):
    if not isinstance(obj, dict):
        return {"type": type(obj).__name__}
    result = {"keys": sorted(obj)}
    for key in ("operation", "arguments", "source_id", "version"):
        if key in obj:
            result[key] = obj[key]
    if "observations" in obj:
        result["observations"] = obj["observations"]
    attacks = obj.get("attacks", (obj.get("graph") or {}).get("attacks", {}))
    if attacks:
        result["attacks"] = attacks
    return result


def audit_run(path):
    run = load_run(path)
    events = run["events"]
    replay = replay_run(run)
    calls = []
    roles = Counter()
    proposed = defaultdict(set)
    ignored_attack_proposals = []
    for start, event in enumerate(events):
        if event["kind"] != "worker_input":
            continue
        role = event["data"]["role"]
        roles[role] += 1
        end = next((i for i in range(start + 1, len(events))
                    if events[i]["kind"] == "worker_input"), len(events))
        local = events[start:end]
        output = next((e for e in local if e["kind"] == "worker_output"), None)
        call = {"input_sequence": event["sequence"], "role": role,
                "role_call_number": roles[role], "identity": event["data"]["identity"],
                "output_sequence": output["sequence"] if output else None}
        if role == "critic":
            payload = json.loads(event["data"]["user"])
            call["critic_input_contract"] = {
                "system_requests_one_operation": "Return one JSON operation per call" in event["data"]["system"],
                "system_requests_critique_envelope": "Return JSON {observations: [text], attacks: {id: Attack}}" in event["data"]["system"],
                "user_required_response": payload.get("required_response"),
                "user_available_tools": payload.get("available_tools"),
                "user_next_step": payload.get("next_step"),
                "user_includes_starter_graph": "starter_graph" in payload,
            }
        if output:
            call["reply_character_count"] = len(output["data"]["reply"])
            call["stripped_reply_character_count"] = len(output["data"]["reply"].strip())
            objects, tail = split_reply(output["data"]["reply"])
            try:
                parsed = extract_json(output["data"]["reply"])
                extracted_error = None
            except Exception as exc:
                parsed, extracted_error = None, f"{type(exc).__name__}: {exc}"
            call.update(top_level_object_count=len(objects), ignored_complete_object_count=max(0, len(objects)-1),
                        nonempty_unparsed_tail=bool(tail.strip()), extraction_error=extracted_error,
                        selected_object_matches_first=bool(objects) and parsed == objects[0]["object"],
                        selected_contract=validation(PromptedCritique if role == "critic" else Operation, parsed),
                        objects=[])
            for number, item in enumerate(objects, 1):
                obj = item["object"]
                record = {"object_number": number, "selected_by_extract_json": number == 1,
                          "normalized_start": item["start"], "normalized_end": item["end"],
                          "summary": summary(obj)}
                if role == "critic":
                    record["prompted_critique_contract"] = validation(PromptedCritique, obj)
                call["objects"].append(record)
                attacks = obj.get("attacks", (obj.get("graph") or {}).get("attacks", {})) if isinstance(obj, dict) else {}
                if isinstance(attacks, dict):
                    proposed[role].update(attacks)
                    if number > 1 and attacks:
                        ignored_attack_proposals.append({"role": role, "output_sequence": output["sequence"],
                                                        "object_number": number, "attack_ids": sorted(attacks)})
        call["admitted_events"] = [
            {"sequence": e["sequence"], "kind": e["kind"],
             "data": summary(e["data"]) if e["kind"] == "operation" else e["data"]}
            for e in local if e["kind"] in {"operation", "critique", "operation_error", "worker_error", "record_repair_requested"}
        ]
        call["tool_results"] = [{"sequence": e["sequence"], "tool": e["data"]["tool"],
                                 "arguments": e["data"]["arguments"]}
                                for e in local if e["kind"] == "tool_result"]
        call["graph_events"] = [{"sequence": e["sequence"], "revision": e["data"]["revision"],
                                  "attack_ids": sorted(e["data"].get("attacks", {}))}
                                 for e in local if e["kind"] == "graph"]
        usage = next((e["data"]["records"] for e in local if e["kind"] == "worker_usage"), [])
        call["usage_records"] = [{k: entry.get(k) for k in (
            "request_status", "invocation_succeeded", "input_tokens", "output_tokens", "reasoning_output_tokens",
            "max_output_tokens", "api_attempts", "failed_api_attempts", "error_type")}
            for entry in usage]
        call["api_attempts"] = sum(x.get("api_attempts", 0) for x in usage)
        call["usage_known"] = all(x.get("usage_known") for x in usage) if usage else False
        calls.append(call)
    source_opens = []
    for event in events:
        if event["kind"] == "tool_result" and event["data"]["tool"] == "open":
            data = event["data"]
            source_opens.append({"sequence": event["sequence"], "arguments": data["arguments"],
                                 "returned_locators": [s["locator"] for s in data["result"].get("segments", [])],
                                 "truncated": data["result"].get("coverage", {}).get("truncated")})
    exposed = defaultdict(set)
    for exposure in run["exposures"]:
        for segment in exposure["segments"]:
            exposed[exposure["worker_id"]].add((segment["source_id"], segment["version"], segment["locator"]))
    graph = run.get("graph") or {}
    attacks = graph.get("attacks", {})
    first_recorded = {}
    for event in events:
        if event["kind"] == "graph":
            for attack_id in event["data"].get("attacks", {}):
                first_recorded.setdefault(attack_id, event["sequence"])
    return {"case": path.name, "path": str(path), "status": run["status"], "stop_reason": run["stop_reason"],
            "model_calls_by_role": dict(roles), "model_calls_reported": run["usage"]["model_calls"],
            "api_attempts": run["usage"]["api_attempts"], "failed_calls": run["usage"]["failed_calls"],
            "failed_api_attempts": run["usage"]["failed_api_attempts"],
            "input_tokens": run["usage"]["input_tokens"], "output_tokens": run["usage"]["output_tokens"],
            "tool_calls_reported": run["usage"]["tool_calls"],
            "errors": run["errors"], "calls": calls,
            "multi_object_outputs": sum(c.get("top_level_object_count", 0) > 1 for c in calls),
            "ignored_complete_objects": sum(c.get("ignored_complete_object_count", 0) for c in calls),
            "source_opens": source_opens,
            "source_spans_exposed_by_role": {role: [dict(zip(("source_id", "version", "locator"), span))
                                                       for span in sorted(spans)] for role, spans in exposed.items()},
            "attack_ids_proposed_by_role_in_all_complete_objects": {role: sorted(ids) for role, ids in proposed.items()},
            "ignored_attack_proposals": ignored_attack_proposals,
            "first_graph_event_recording_attack": first_recorded,
            "final_recorded_attacks": attacks,
            "final_kernel_attack_labels": (run.get("evaluation") or {}).get("attack_labels", {}),
            "replay": {k: v for k, v in replay.items() if k != "evaluation"}}


root = Path(__file__).resolve().parent.parent
protocol = json.loads((root / "protocol.json").read_text())
order = [f"{x['question']}-{x['mutation'] or 'baseline'}" for x in protocol["order"]]
runs = [audit_run(root / name) for name in order if (root / name / "result.json").exists()]
audit = {
    "kind": "mechanical_protocol_audit",
    "scope": "Saved worker text, controller events, actual tool results and model-free replay; no substantive truth adjudication.",
    "totals_scope": "Only completed persisted result/ledger pairs; unpersisted interrupted attempts are excluded and their calls, usage, cost and outcome cannot be inferred from these totals.",
    "expected_runs": len(order), "completed_runs": len(runs),
    "pending_runs": [name for name in order if not (root / name / "result.json").exists()],
    "interruption_record": json.loads((root / "interruption.json").read_text()) if (root / "interruption.json").exists() else None,
    "limitations": [
        "Provider SDK response output/content items and their boundaries were not persisted. Multiple objects are proven in worker_output.reply, but their origin as separate provider items versus a single generated text span cannot be determined.",
        "The audit-only PromptedCritique schema requires observations:list[str] and attacks:dict[str,Attack] with no extra envelope keys. Runtime itself has no critic envelope model; it calls .get directly.",
        "Graph-recorded attacks and kernel IN/OUT labels are distinct. This audit does not adjudicate whether an attack is substantively warranted.",
        "Replay verifies ledger/result consistency and recomputes the final evaluation from the persisted graph/exposures. It does not reconstruct or validate the original worker protocol decisions.",
        "failed_calls includes parser/schema/graph-admission failures; failed_api_attempts separately counts adapter-reported failed provider requests.",
        "Current_source_versions contains availability metadata and is not proof a source was opened. Actual opens and exposed source spans are reported separately."
    ],
    "code_references": {
        "first_object_selection": "inquiry/llm.py:31-45; raw_decode consumed offset discarded",
        "sdk_text_selection": "inquiry/v1/workers.py:145-208; OpenAI output_text returned and Anthropic text blocks joined; only usage metadata persisted",
        "logging_and_extracting": "inquiry/v1/runtime.py:487-517; worker_output stores flattened text then extract_json",
        "proposer_validation": "inquiry/v1/runtime.py:558-568; Operation.model_validate before tool dispatch",
        "critic_processing": "inquiry/v1/runtime.py:602-629; critique logged, observations/attacks read with .get, only nonempty attacks trigger InquiryGraph validation",
        "replay_scope": "inquiry/v1/runtime.py:689-706"
    },
    "totals": {
        "calls_by_role": dict(sum((Counter(r["model_calls_by_role"]) for r in runs), Counter())),
        "api_attempts": sum(r["api_attempts"] for r in runs),
        "failed_api_attempts": sum(r["failed_api_attempts"] for r in runs),
        "input_tokens": sum(r["input_tokens"] for r in runs),
        "output_tokens": sum(r["output_tokens"] for r in runs),
        "multi_object_outputs": sum(r["multi_object_outputs"] for r in runs),
        "ignored_complete_objects": sum(r["ignored_complete_objects"] for r in runs),
        "actual_source_opens": sum(len(r["source_opens"]) for r in runs),
        "critic_selected_contract_invalid": sum(not c["selected_contract"]["valid"] for r in runs for c in r["calls"] if c["role"] == "critic" and "selected_contract" in c),
        "worker_outputs_with_extraction_error": sum(bool(c.get("extraction_error")) for r in runs for c in r["calls"]),
        "critic_attack_proposals_distinct_within_each_run": sum(len(r["attack_ids_proposed_by_role_in_all_complete_objects"].get("critic", [])) for r in runs),
        "attacks_recorded_in_graphs_distinct_within_each_run": sum(len(r["first_graph_event_recording_attack"]) for r in runs),
        "final_kernel_attack_labels": dict(sum((Counter(r["final_kernel_attack_labels"].values()) for r in runs), Counter())),
        "all_ledger_valid": all(r["replay"].get("ledger_valid") for r in runs),
        "graph_evaluations_reproduced": sum(r["replay"].get("evaluation_reproduced") is True for r in runs),
        "runs_without_graph_to_replay": sum(r["replay"].get("evaluation_reproduced") is None for r in runs),
        "graph_evaluation_mismatches": sum(r["replay"].get("evaluation_reproduced") is False for r in runs)
    },
    "runs": runs
}
output = root / "audit" / "protocol_audit.json"
output.write_text(json.dumps(audit, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"output": str(output), "completed_runs": audit["completed_runs"], "pending_runs": audit["pending_runs"], "totals": audit["totals"]}, indent=2))
